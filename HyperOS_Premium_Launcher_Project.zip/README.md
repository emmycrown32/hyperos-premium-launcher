# HyperOS Premium Launcher — prototype 2

An independent Android launcher inspired by Xiaomi HyperOS (not affiliated with Xiaomi).

## Included
- HyperOS-inspired gradient home screen
- Large clock/date and decorative weather card
- App drawer with text search
- Launch installed apps from tiles
- Personalisation menu: five backgrounds, two icon styles, four accent colours
- Settings shortcut
- No ads, subscriptions, analytics, or location permission in this prototype

## Build an APK
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync (internet is needed on first build).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the debug APK in `app/build/outputs/apk/debug/`.

## Select it as Home
After installing the APK, open **Settings > Apps > Default apps > Home app** (wording varies by device) and select **HyperOS Premium**.

## Limitations
This is still a prototype, not an installable APK itself. The weather card is a visual placeholder, not live weather. Android system UI, lock screen, notification shade, and system settings remain Xiaomi's. App visibility can vary by Android/HyperOS version.

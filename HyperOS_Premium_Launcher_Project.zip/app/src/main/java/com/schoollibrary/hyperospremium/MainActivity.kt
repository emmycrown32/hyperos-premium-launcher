package com.schoollibrary.hyperospremium

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var chosenWallpaper = 0
    private var iconStyle = 0
    private var accent = 0
    private val wallpapers = listOf(
        intArrayOf(Color.rgb(23, 31, 66), Color.rgb(52, 57, 111), Color.rgb(29, 39, 77)),
        intArrayOf(Color.rgb(11, 69, 86), Color.rgb(39, 131, 144), Color.rgb(18, 45, 80)),
        intArrayOf(Color.rgb(74, 38, 95), Color.rgb(129, 75, 142), Color.rgb(31, 42, 88)),
        intArrayOf(Color.rgb(105, 42, 52), Color.rgb(172, 91, 92), Color.rgb(56, 39, 74)),
        intArrayOf(Color.rgb(20, 70, 54), Color.rgb(68, 135, 106), Color.rgb(24, 45, 67))
    )
    private val accents = intArrayOf(
        Color.rgb(115, 174, 255), Color.rgb(255, 160, 108),
        Color.rgb(183, 151, 255), Color.rgb(104, 225, 190)
    )
    private val ink = Color.rgb(246, 248, 255)
    private val muted = Color.rgb(193, 202, 226)
    private lateinit var root: LinearLayout
    private lateinit var mainContent: LinearLayout
    private lateinit var searchInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 27, 55)
        window.navigationBarColor = Color.rgb(20, 27, 55)
        showHome()
    }

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            background = gradient()
        }
        val scroll = ScrollView(this)
        mainContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(mainContent)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(label("HYPER  •  PREMIUM", 12, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(buttonText("⚙", 25) { showSettings() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        mainContent.addView(top)
        mainContent.addView(space(18))

        val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
        mainContent.addView(label(time, 62, ink, false))
        mainContent.addView(label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 15, muted, false))
        mainContent.addView(space(20))

        val weather = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = rounded(Color.argb(34, 255, 255, 255), 22)
        }
        weather.addView(label("☀", 30, accents[accent], true))
        val weatherText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        weatherText.addView(label("Good day", 16, ink, true))
        weatherText.addView(label("Weather widget preview • tap for weather settings", 11, muted, false))
        val weatherLp = LinearLayout.LayoutParams(0, -2, 1f)
        weatherLp.setMargins(dp(12), 0, 0, 0)
        weather.addView(weatherText, weatherLp)
        weather.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Weather widget")
                .setMessage("This prototype shows a visual weather card. Live weather needs an internet weather service and location permission, which are not included yet.")
                .setPositiveButton("OK", null).show()
        }
        mainContent.addView(weather, LinearLayout.LayoutParams(-1, -2))
        mainContent.addView(space(18))

        searchInput = EditText(this).apply {
            hint = "⌕   Search installed apps"
            setHintTextColor(muted)
            setTextColor(ink)
            textSize = 15f
            singleLine = true
            background = rounded(Color.argb(40, 255, 255, 255), 26)
            setPadding(dp(16), 0, dp(16), 0)
            setOnFocusChangeListener { _, focused -> if (focused) showDrawer("") }
        }
        mainContent.addView(searchInput, LinearLayout.LayoutParams(-1, dp(50)))
        searchInput.setOnClickListener { showDrawer("") }
        mainContent.addView(space(18))
        mainContent.addView(label("YOUR APPS", 12, muted, true))
        mainContent.addView(space(10))

        val apps = launchableApps().filter { it.packageName != packageName }
        val preferred = listOf("Phone", "Messages", "Camera", "Chrome", "Settings", "Photos", "Play Store", "Clock")
        val selected = preferred.mapNotNull { name -> apps.firstOrNull { it.label.toString().contains(name, true) } }
            .distinctBy { it.packageName }.take(8)
        val display = if (selected.isNotEmpty()) selected else apps.take(8)
        for (start in display.indices step 4) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            display.drop(start).take(4).forEachIndexed { index, app ->
                val pos = start + index
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(2), dp(8), dp(2), dp(8))
                    setOnClickListener { launch(app.packageName) }
                }
                val icon = TextView(this).apply {
                    text = if (iconStyle == 1) app.label.toString().take(1).uppercase(Locale.getDefault()) else "●"
                    textSize = if (iconStyle == 1) 24f else 22f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(accents[(pos + accent) % accents.size], if (iconStyle == 1) 26 else 18)
                }
                tile.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
                tile.addView(space(6))
                tile.addView(label(app.label.toString().take(11), 10, ink, false).apply { gravity = Gravity.CENTER })
                row.addView(tile, LinearLayout.LayoutParams(0, -2, 1f))
            }
            mainContent.addView(row)
        }

        mainContent.addView(space(14))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(16), dp(17), dp(16))
            background = rounded(Color.argb(34, 255, 255, 255), 24)
        }
        card.addView(label("A little more space to breathe.", 17, ink, true))
        card.addView(space(6))
        card.addView(label("Minimal  •  Personal  •  Yours", 13, muted, false))
        mainContent.addView(card, LinearLayout.LayoutParams(-1, -2))

        val dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = rounded(Color.argb(48, 255, 255, 255), 30)
        }
        display.take(4).forEachIndexed { index, app ->
            val item = TextView(this).apply {
                text = if (iconStyle == 1) app.label.toString().take(1).uppercase(Locale.getDefault()) else "●"
                textSize = 21f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = rounded(accents[(index + accent) % accents.size], 20)
                setOnClickListener { launch(app.packageName) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
            lp.setMargins(dp(5), 0, dp(5), 0)
            dock.addView(item, lp)
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun showDrawer(initial: String) {
        root.removeAllViews()
        root.setPadding(dp(20), dp(24), dp(20), dp(16))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("All apps", 28, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(buttonText("⌂", 26) { showHome() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(header)
        root.addView(space(12))
        val search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(muted)
            setTextColor(ink)
            textSize = 16f
            singleLine = true
            background = rounded(Color.argb(40, 255, 255, 255), 24)
            setPadding(dp(16), 0, dp(16), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun populate(filter: String) {
            list.removeAllViews()
            launchableApps().filter { it.packageName != packageName }
                .filter { it.label.toString().contains(filter, true) }
                .sortedBy { it.label.toString().lowercase(Locale.getDefault()) }
                .forEachIndexed { index, app ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(8), dp(8), dp(8), dp(8))
                        setOnClickListener { launch(app.packageName) }
                    }
                    val icon = TextView(this).apply {
                        text = app.label.toString().take(1).uppercase(Locale.getDefault())
                        textSize = 18f
                        gravity = Gravity.CENTER
                        setTextColor(Color.WHITE)
                        background = rounded(accents[(index + accent) % accents.size], 16)
                    }
                    row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
                    val name = label(app.label.toString(), 16, ink, false)
                    val lp = LinearLayout.LayoutParams(0, -2, 1f)
                    lp.setMargins(dp(14), 0, 0, 0)
                    row.addView(name, lp)
                    list.addView(row)
                }
        }
        populate(initial)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        setContentView(root)
    }

    private fun showSettings() {
        val options = arrayOf("Change wallpaper colour", "Change icon style", "Choose accent colour", "Open phone settings", "About this launcher")
        AlertDialog.Builder(this)
            .setTitle("Personalise your launcher")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseWallpaper()
                    1 -> chooseIconStyle()
                    2 -> chooseAccent()
                    3 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    4 -> AlertDialog.Builder(this).setTitle("HyperOS Premium")
                        .setMessage("An independent HyperOS-inspired launcher prototype. It does not replace Xiaomi's operating system, lock screen, notification shade, or system controls.")
                        .setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun chooseWallpaper() {
        val names = arrayOf("Midnight blue", "Ocean teal", "Royal violet", "Rose dusk", "Forest green")
        AlertDialog.Builder(this).setTitle("Choose a background")
            .setSingleChoiceItems(names, chosenWallpaper) { dialog, which ->
                chosenWallpaper = which
                showHome()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseIconStyle() {
        val names = arrayOf("Minimal dot icons", "Letter icons")
        AlertDialog.Builder(this).setTitle("Icon style")
            .setSingleChoiceItems(names, iconStyle) { dialog, which ->
                iconStyle = which
                showHome()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseAccent() {
        val names = arrayOf("Sky blue", "Warm peach", "Soft violet", "Mint green")
        AlertDialog.Builder(this).setTitle("Accent colour")
            .setSingleChoiceItems(names, accent) { dialog, which ->
                accent = which
                showHome()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun launchableApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            ?: Toast.makeText(this, "Couldn't open this app", Toast.LENGTH_SHORT).show()
    }

    private fun gradient(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, wallpapers[chosenWallpaper]
    ).apply { cornerRadius = 0f }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun buttonText(text: String, size: Int, action: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        gravity = Gravity.CENTER
        setTextColor(ink)
        setOnClickListener { action() }
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
